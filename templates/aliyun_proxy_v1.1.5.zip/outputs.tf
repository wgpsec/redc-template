output "ecs_ip" {
  value       = "${alicloud_instance.instance[*].public_ip}"
  description = "ip"
}
output "ecs_password" {
  value       = nonsensitive(local.instance_password)
  description = "vps password."
}
output "ssh_user" {
  description = "SSH 登录用户名"
  value       = "root"
}

output "ssh_commands" {
  description = "SSH 连接命令"
  value       = [for ip in alicloud_instance.instance[*].public_ip : "ssh root@${ip}"]
}
