# Dify

这是一个用于自动安装 Dify 的 userdata 模板。

## 功能说明

1. 克隆 Dify 官方仓库
2. 使用 Docker Compose 启动 Dify
