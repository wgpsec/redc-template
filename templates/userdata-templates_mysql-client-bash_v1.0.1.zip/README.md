# MySQL 客户端安装

这是一个用于安装 MySQL 客户端的 userdata 模板。

## 功能说明

1. 更新软件包列表
2. 安装 MySQL 客户端
