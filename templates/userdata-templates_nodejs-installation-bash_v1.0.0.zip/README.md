# Node.js 安装

这是一个用于安装 Node.js 的 userdata 模板。

## 功能说明

1. 添加 Node.js 18.x 官方 APT 源
2. 安装 Node.js 和 npm
3. 验证安装
