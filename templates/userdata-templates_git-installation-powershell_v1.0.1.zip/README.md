# Git 安装

这是一个用于安装 Git 的 userdata 模板。

## 功能说明

1. 通过 Chocolatey 安装 Git
2. 验证安装
