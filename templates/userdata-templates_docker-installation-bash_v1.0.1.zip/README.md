# Docker 安装

这是一个用于安装 Docker 引擎的 userdata 模板。

## 功能说明

1. 下载并执行 Docker 安装脚本
2. 启动并启用 Docker 服务
3. 将当前用户添加到 docker 组
