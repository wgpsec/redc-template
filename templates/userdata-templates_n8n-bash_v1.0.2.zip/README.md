# n8n

这是一个用于自动安装 n8n 的 userdata 模板。

## 功能说明

1. 全局安装 n8n
