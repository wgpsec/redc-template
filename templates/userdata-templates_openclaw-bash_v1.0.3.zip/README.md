# OpenClaw

这是一个用于自动安装 OpenClaw 的 userdata 模板。

## 功能说明

1. 执行官方安装脚本
