# IIS 安装

这是一个用于安装 IIS Web 服务器的 userdata 模板。

## 功能说明

1. 安装 IIS Web 服务器
2. 安装 IIS 管理工具
