# Docker Compose 安装

这是一个用于安装 Docker Compose 的 userdata 模板。

## 功能说明

1. 下载并安装 Docker Compose v2.24.0
2. 设置执行权限
3. 验证安装
