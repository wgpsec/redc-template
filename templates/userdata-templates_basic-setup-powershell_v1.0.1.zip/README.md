# 基础设置

这是一个用于基础系统设置，安装 Chocolatey 的 userdata 模板。

## 功能说明

1. 设置执行策略
2. 安装 Chocolatey 包管理器
