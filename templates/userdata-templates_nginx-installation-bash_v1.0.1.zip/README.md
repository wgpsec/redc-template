# Nginx 安装

这是一个用于安装 Nginx Web 服务器的 userdata 模板。

## 功能说明

1. 更新软件包列表
2. 安装 Nginx
3. 启动并启用 Nginx 服务
